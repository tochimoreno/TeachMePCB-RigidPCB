Filelist:
ATmega328P_Xplained_Mini_layer_plots_release_rev4.pdf : PCB Layer Plots
ATmega328P_Xplained_Mini_design_documentation_release_rev4.pdf : Design Documentation
BOM\Bill of Materials Print- ATmega328P_Xplained_Mini_release_rev4.xls : BOM, fitted components
ExportSTEP\ATmega328P_Xplained_Mini_release_rev4.step : 3D Model of PCBA
NC Drill\ATmega328P_Xplained_Mini_release_rev4.drl : Drill files, gerber
NC Drill\ATmega328P_Xplained_Mini_release_rev4.drr : Drill files, report
ODB\ATmega328P_Xplained_Mini_release_rev4.zip : ODB++ Files
Pick Place\Pick Place for ATmega328P_Xplained_Mini_release_rev4.txt : Pick and Place file, component placement
Test Points\Assembly Testpoint Report for ATmega328P_Xplained_Mini_release_rev4.txt : Assembly Testpoint report, txt
Gerber\ATmega328P_Xplained_Mini_release_rev4.GM1 : Gerber files for Mechanical 1
Gerber\ATmega328P_Xplained_Mini_release_rev4.GTO : Gerber files for Top Overlay
Gerber\ATmega328P_Xplained_Mini_release_rev4.GTL : Gerber files for Top Layer
Gerber\ATmega328P_Xplained_Mini_release_rev4.GBL : Gerber files for Bottom Layer
Gerber\ATmega328P_Xplained_Mini_release_rev4.GBO : Gerber files for Bottom Overlay
Gerber\ATmega328P_Xplained_Mini_release_rev4.GBS : Gerber files for Bottom Solder
Gerber\ATmega328P_Xplained_Mini_release_rev4.GTS : Gerber files for Top Solder
Gerber\ATmega328P_Xplained_Mini_release_rev4.GTP : Gerber files for Top Paste
Gerber\ATmega328P_Xplained_Mini_release_rev4.GP2 : Gerber files for Power Plane
Gerber\ATmega328P_Xplained_Mini_release_rev4.GP1 : Gerber files for Ground Plane
NC Drill\ATmega328P_Xplained_Mini_RoundHoles_release_rev4.txt : Drill files, ASCII RH
NC Drill\ATmega328P_Xplained_Mini_SlotHoles_release_rev4.txt : Drill files, ASCII SH
